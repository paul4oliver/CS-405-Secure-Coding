// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>
#include <string>

/* PROBLEM: Data needs to be encrypted !
*  
*  SOLUTION: Implement XOR-based encryption character by character across a file of data
*            Implemented the logic to read a text file in the specified format into a string in the read_file method.
*            Implemented the logic to save a text file in the specified format in the save_data_file method
*            Implemented exception handling to catch errors associated with reading and writing to files
*/

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    { 
    // transform each character based on an xor of the key modded constrained to key length using a mod
        output[i] ^= key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

// Method to open a file and load the file into a string, returns file text as a string
std::string read_file(const std::string& filename)
{
   std::string file_line;
   std::string file_text;
   
   // Create input stream to open/read file
   std::cout << "Opening " << filename << std::endl;
   std::ifstream MyReadFile(filename);

   // Try-catch blocks to check that input stream is able to open the file
   try {
       // Throw exception if unable to read file 
       if (!MyReadFile) {
           throw std::system_error(errno, std::system_category(), "Failed to open " + filename);
       }

       std::cout << "Reading " << filename << std::endl;

       // Use a while loop together with the getline() function to read the file line by line
       while (std::getline(MyReadFile, file_line)) {
           
           // Add new line character to each line and add each line to file_text
           file_line = file_line + "\n";
           file_text += file_line;
       }

       // Close input stream/file
       std::cout << "Closing " << filename << std::endl;
       MyReadFile.close();

   }catch (const std::system_error& e){
       std::cout << e.what() << " (" << e.code() << ")" << std::endl;
   }

  return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

  return student_name;
}

// Created a fucntion that returns the timestamp
std::string get_timestamp()
{
    const int MAXLEN = 80;
    char timestamp[MAXLEN];
    time_t t = time(0);
    strftime(timestamp, MAXLEN, "%Y-%m-%d", localtime(&t));

    return timestamp;
}

// This method saves encrypted/decrypted data to a file
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    // Create output stream to write data to file
    std::cout << std::endl << "Opening " << filename << std::endl;
    std::ofstream MyWriteFile(filename);

    // Try-catch blocks to check that output stream is able to write to the file
    try {
        // Throw exception if unable to write to file 
        if (!MyWriteFile) {
            throw std::system_error(errno, std::system_category(), "Failed to write to " + filename);
        }

        std::cout << "Writing to " << filename << std::endl;

        //  Line 1: student name
        MyWriteFile << "Student name: " << student_name << std::endl;
        //  Line 2: timestamp (yyyy-mm-dd)
        MyWriteFile << "Timestamp: " << get_timestamp() << std::endl;
        //  Line 3: key used
        MyWriteFile << "Key used: " << key << std::endl;
        //  Line 4+: data
        MyWriteFile << "Data:\n" << data << std::endl;

        // Close output stream/file 
        std::cout << "Closing " << filename << std::endl;
        MyWriteFile.close();
    }
    catch (const std::system_error& e) {
        std::cout << e.what() << " (" << e.code() << ")" << std::endl;
    }
}

int main()
{
  std::cout << "Encyption Decryption Test!\n" << std::endl;

  const std::string file_name = "inputdatafile.txt";
  const std::string encrypted_file_name = "encrypteddatafile.txt";
  const std::string decrypted_file_name = "decrytpteddatafile.txt";
  const std::string source_string = read_file(file_name);
  const std::string key = "password";

  // get the student name from the data file
  const std::string student_name = get_student_name(source_string);

  // encrypt sourceString with key
  const std::string encrypted_string = encrypt_decrypt(source_string, key);

  // save encrypted_string to file
  save_data_file(encrypted_file_name, student_name, key, encrypted_string);

  // decrypt encryptedString with key
  const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

  // save decrypted_string to file
  save_data_file(decrypted_file_name, student_name, key, decrypted_string);

  std::cout << std::endl << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
