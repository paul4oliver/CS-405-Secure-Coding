// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.

// Problem: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
// even though it is a constant and the compiler buffer overflow checks are on.

#include <iomanip>
#include <iostream>

// Macros to define values
#define MAX_VAL_LEN 20
#define X_VAL -1

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	const std::string account_number = "CharlieBrown42";
	char user_input[MAX_VAL_LEN];
	int x = X_VAL;

	std::cout << "Enter a value: ";

	// Solution: Use try-catch statement to get user input
	try {
		// Use getline function to get user input and set max character limit to prevent buffer overflow
		std::cin.getline(user_input, sizeof(user_input) + 1);

		// Throw exception if input exceeds max value length
		if (!std::cin) {
			throw x;
		}

		std::cout << "\nYou entered: " << user_input << std::endl;
		std::cout << std::endl << "Account Number = " << account_number << std::endl;
	}
	catch (int x) {
		// Catch error if buffer overflow occurred and output message
		std::cout << "\nError: The value entered is too long." << std::endl;
	}
	catch (...) {
		// Catch any error that may arise just in case
		std::cout << std::endl << "Error: An error occurred.";
	}
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
