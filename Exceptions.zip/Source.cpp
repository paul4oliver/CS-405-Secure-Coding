/* Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.

   Problem: Some of the code in the application seems to terminate abruptly, crashing to the desktop without any warnings or 
   information displayed to the user.

   Solution: Created exception try-blocks & customer exception, which will: 
                                                                   Wrap code that can potentially throw exceptional errors
                                                                   Throw standard & custom C++ exceptions
                                                                   Catch exceptions derived from std::exception
                                                                   Catch all unhandled exceptions                                                            
*/

#include <iostream>
#include <exception>    // Added header for std::exception
 
/* Created a custom class that inherits properties from the std::exception class and overrides the what() function to return a custom 
   error message string.
   
   Refereces: https://rollbar.com/blog/cpp-custom-exceptions/
              https://www.delftstack.com/howto/cpp/cpp-custom-exception/
   */
class MyCustomException : public std::exception {
public:
    const char* what() const throw()
    {
        return "custom_exception";
    }
};


bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throw standard exception
    throw std::invalid_argument("invalid_argument");

    return true;
}
void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

     // Created an exception handler that catches an std::exception thrown by do_even_more_custom_application_logic()
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception& e) {
        // When an exception is caught, display a message and the exception.what() then continue processing
        std::cout << "Exception caught: " << e.what()  << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

    // Throw custom exception derived from std::exception
    throw MyCustomException();    
}

float divide(float num, float den)
{
    /* Created an if-statement that will throw an exception to deal with divide by zero errors using a standard C++ defined exception
    
       References: https://learn.microsoft.com/en-us/dotnet/csharp/fundamentals/exceptions/
                   https://stackoverflow.com/questions/6121623/catching-exception-divide-by-zero
    */
    if (den == 0) {
        throw std::overflow_error("divide_by_zero");
    }

    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // Created an exception handler that catches the exception thrown by divide()
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::overflow_error e) {
        std::cout << "Exception caught: " << e.what() << "\n";
    } 
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    /* Created an exception handler to catch: custom exception derived from std::exception
                                              std::exception
                                              uncaught (all other) exceptions 
    */                                 
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (MyCustomException& e) {
        std::cout << "Exception caught : " << e.what() << "\n";
    }
    catch (std::exception& e) {
        std::cout << "Exception caught : " << e.what() << "\n";
    }
    catch (...) {
        std::cout << "Exception caught : uncaught_exception\n";
    } 
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu