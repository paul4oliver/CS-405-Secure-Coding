// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());
     
    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
}   

// Test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 5
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CheckMaxSizeIsGreaterOrEqual)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->max_size(), collection->size());

    collection->resize(1);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if empty, the size must be 1
    EXPECT_EQ(collection->size(), 1);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->max_size(), collection->size());

    collection->resize(5);

    // is the collection empty now?
    EXPECT_FALSE(collection->empty());

    // if empty, the size must be 5
    EXPECT_EQ(collection->size(), 5);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->max_size(), collection->size());

    collection->resize(10);

    // is the collection empty now?
    EXPECT_FALSE(collection->empty());

    // if empty, the size must be 10
    EXPECT_EQ(collection->size(), 10);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CheckCapacityIsGreaterOrEqual)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->capacity(), collection->size());

    collection->resize(1);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if empty, the size must be 1
    EXPECT_EQ(collection->size(), 1);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->capacity(), collection->size());

    collection->resize(5);

    // is the collection empty now?
    EXPECT_FALSE(collection->empty());

    // if empty, the size must be 5
    EXPECT_EQ(collection->size(), 5);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->capacity(), collection->size());

    collection->resize(10);

    // is the collection empty now?
    EXPECT_FALSE(collection->empty());

    // if empty, the size must be 10
    EXPECT_EQ(collection->size(), 10);

    // max size must be greater than or equal to the size
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection
TEST_F(CollectionTest, EnsureResizingIncreasesVectorSize)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    collection->resize(3);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 3
    ASSERT_EQ(collection->size(), 3);
}

// Test to verify resizing decreases the collection
TEST_F(CollectionTest, EnsureResizingDecreasesVectorSize)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(3);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 3
    EXPECT_EQ(collection->size(), 3);

    collection->resize(1);

    // is the collection empty now?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
}

// Test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, EnsureResizingDecreasesVectorSizeToZero)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(3);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 3
    EXPECT_EQ(collection->size(), 3);

    collection->resize(0);

    // is the collection empty now?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection
TEST_F(CollectionTest, EnsureVectorIsClear)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(3);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 3
    EXPECT_EQ(collection->size(), 3);

    collection->clear();

    // is the collection empty now?
    EXPECT_TRUE(collection->empty());

    // if  empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EnsureVectorErases)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(3);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 3
    EXPECT_EQ(collection->size(), 3);

    collection->erase(collection->begin(), collection->end());

    // is the collection empty now?
    EXPECT_TRUE(collection->empty());

    // if  empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    // is the capacity 0?
    EXPECT_EQ(collection->capacity(), 0);

    collection->reserve(5);

    // is the collection still empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size should not have changed
    ASSERT_EQ(collection->size(), 0);

    // has the capacity changed? if so, the capacity must be 5
    ASSERT_EQ(collection->capacity(), 5);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, VerifyOutOfRangeExcpetionThrown)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    // if the size is 0, index 1 is out of range
    ASSERT_THROW(collection->at(1), std::out_of_range);
}

/* Custom Tests: 1 Positive & 1 Negative */

// Test to verify that pop_back removes the last element
TEST_F(CollectionTest, CheckPopBackRemovesLastElement)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    add_entries(2);
    int x = collection->at(0);
    int y = collection->at(1);

    // is the collection still empty?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 2
    EXPECT_EQ(collection->size(), 2);

    // if not empty, element at index 0 should be equal to int x
    EXPECT_EQ(collection->at(0), x);

    // if not empty, element at index 1 should be equal to int y
    EXPECT_EQ(collection->at(1), y);

    collection->pop_back();

    // is the collection empty now?
    EXPECT_FALSE(collection->empty());

    // if not empty, the size must be 1
    EXPECT_EQ(collection->size(), 1);

    // if not empty, element at index 0 should be equal to int x
    ASSERT_EQ(collection->at(0), x);
}

// Test to verify that std::length_error exception is thrown when the capacity is increased using reserve
// to max size + 1
TEST_F(CollectionTest, VerifyLengthErrorExcpetionThrown)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty());

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    // if empty, the capacity must be 0
    EXPECT_EQ(collection->capacity(), 0);

    // increasing the vector's capacity to max size + 1 using reserve should thrown length_error exception 
    ASSERT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);
}